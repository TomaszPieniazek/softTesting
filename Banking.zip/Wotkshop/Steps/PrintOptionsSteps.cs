﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PageObjects.HomePage;
using PageObjects.HomePage.Notices.PrintOptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Wotkshop.Steps
{
    [Binding]
    class PrintOptionsSteps
    {
        private IWebDriver driver= HomePage.sendDriver();
        private PrintOptions poPage;

        [When(@"init PrintOptions")]
        public void ThenUserIsInPrintOptionsPage()
        {
            poPage = new PrintOptions(driver);
            PageFactory.InitElements(driver, poPage);
        }


        [Then(@"user checks if all elements on print options view exists")]
        public void ThenUserChecksIfAllElementsOnPrintOptionsViewExists()
        {
            Thread.Sleep(2000);

            Assert.IsTrue(poPage.isElementPresent(poPage.SaveChangesButton), " Save Changes should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.SiteID), " Site ID should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.SiteIDArrow), " Site ID Arrow should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.Attention), " Attention input should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.FirstAddress), " FirstAddress input should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.SecondAddress), " SecondAddress input should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.City), " City input should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.State), " State input should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.ZipCode), " Zip Code input should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.RemoveAddressCheckbox), " Remove Address checkbox should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.CaseSort), " Case Sort dropdown should be visible");
            Assert.IsTrue(poPage.isElementPresent(poPage.PrintMode), " Print Mode dropdown should be visible");

            Thread.Sleep(2000);
        }


    }
}
