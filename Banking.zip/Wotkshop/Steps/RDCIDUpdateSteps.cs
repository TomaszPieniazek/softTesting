﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.PageObjects;
using PageObjects.HomePage;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PageObjects.HomePage.Support.RDCIDUpdate;

namespace Wotkshop.Steps
{

    [Binding]
    public class RDCIDUpdateSteps
    {
        
        private RDCIDUpdate rdcidUpdate;

        // Declare driver as driver returned by HomePage.sendDriver() method.
        private IWebDriver driver = HomePage.sendDriver();

        private RDCIDUpdateSteps() { 
        }

        // step do init page related to steps
        [When(@"init RDCIDUpdate")]
        public void InitCaseMaitenance()
        {
            rdcidUpdate = new RDCIDUpdate(driver);
            PageFactory.InitElements(driver, rdcidUpdate);
        }

        [When(@"user expands filter section in rdcid update section")]
        public void WhenUserExpandsFilterSectionInRdcidUpdateSection()
        {
            Thread.Sleep(2000);
            rdcidUpdate.expandFilterSectionIfNeeded();
        }


        [Then(@"user checks if all elements on rdcid update view exists")]
        public void ThenUserChecksIfAllElementsOnRdcidUpdateViewExists()
        {
            Thread.Sleep(1500);
            Assert.IsTrue(rdcidUpdate.isElementPresent(rdcidUpdate.FiduciaryName), " Fiduciary Name input is not visible");
            Assert.IsTrue(rdcidUpdate.isElementPresent(rdcidUpdate.FiduciarySurname), " Fiduciary Surname input is not visible");
            Assert.IsTrue(rdcidUpdate.isElementPresent(rdcidUpdate.SiteID), "Site ID input is not visible");
            Assert.IsTrue(rdcidUpdate.isElementPresent(rdcidUpdate.FilterButton), " Filter Button is not visible");
            Assert.IsTrue(rdcidUpdate.checkFilterArrowsInRdcidUpdate(), " Filter Arrows are not visible");
        }


    }
}
