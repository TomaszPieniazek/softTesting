﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.PageObjects;
using PageObjects.HomePage;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using PageObjects.HomePage.Support.CaseMaintenance;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
    


namespace Wotkshop.Steps
{

    [Binding]
    public class CaseMaintenanceSteps
    {
        
        private CaseMaintenance casePage;

        // Declare driver as driver returned by HomePage.sendDriver() method.
        private IWebDriver driver = HomePage.sendDriver();

        private CaseMaintenanceSteps() { 
        }

        // step do init page related to steps
        [When(@"init CaseMaintenance")]
        public void InitCaseMaitenance()
        {
            casePage = new CaseMaintenance(driver);
            PageFactory.InitElements(driver, casePage);
            
        }

        [When(@"user clicks on refresh button")]
        public void ClickOnRefreshButton()
        {

            casePage.WaitForElementIsVisible(casePage.RefreshButton);
            casePage.RefreshButton.Click();
        }

        [When(@"user clicks on addEntry button")]
        public void ClicksOnAddEntry()
        {

            casePage.WaitForElementIsVisible(casePage.RefreshButton);
            casePage.RefreshButton.Click();
        }

        // step for assertions
        [Then(@"user checks if all elements on case maintenance view exists")]
        public void UserChecksCaseMaintElements()
        {
            Thread.Sleep(1500);
            Assert.IsTrue(casePage.isElementPresent(casePage.AddEntryButton)," Entry Button should be visible");
            Assert.IsTrue(casePage.isElementPresent(casePage.DeleteButton), "DeleteButton should be visible");
            Assert.IsTrue(casePage.isElementPresent(casePage.DownloadButton), "AddDownloadButton should be visible");
            Assert.IsTrue(casePage.isElementPresent(casePage.EditButton), "EditButton should be visible");
            Assert.IsTrue(casePage.isElementPresent(casePage.stEntryAtUpInactiv), "stEntryAtUpInactiv should be visible");
          //  Assert.IsTrue(casePage.isElementPresent(casePage.stEntryAtUpActive), "stEntryAtUpActive should be visible");


        }
    }
}
