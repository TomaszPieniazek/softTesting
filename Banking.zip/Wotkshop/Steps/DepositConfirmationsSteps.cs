﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PageObjects.HomePage;
using PageObjects.HomePage.Notices.DepositConfirmations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Wotkshop.Steps
{
    [Binding]
    class DepositConfirmationsSteps
    {
        private IWebDriver driver = HomePage.sendDriver();
        private DepositConfirmationsPage dcPage;

        [When(@"init DepositConfirmations")]
        public void WhenInitDepositConfirmations()
        {
            dcPage = new DepositConfirmationsPage(driver);
            PageFactory.InitElements(driver, dcPage);
        }



        [Then(@"user checks if all elements on deposit confirmations view exists")]
        public void ThenUserChecksIfAllElementsOnPrintOptionsViewExists()
        {
            Thread.Sleep(2000);

            Assert.IsTrue(dcPage.isElementPresent(dcPage.expandFilterButtonMinus), " Minus filter button should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.accountNumberInput), " Account Number input should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.selectBankCodeDropDown), " Bank Code dropdown should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.startDateInputDatePicker), " Start Date  should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.endDateInputDatePicker), " End Date should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.filterButtonSubmit), " Filter button should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByBankCodeAsc), " Bank Code sort asc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByBankCodeDesc), " Bank Code sort desc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByAccountAsc), " Account sort asc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByAccountDesc), " Account sort desc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByDepositTypeAsc), " Deposit Type sort asc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByDepositTypeDesc), " Deposit Type sort desc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByTransDateDesc), " Transaction Date sort desc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByTransDateAsc), " Transaction Date sort asc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByRefNoAsc), " Reference Number sort asc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByRefNoDesc), " Reference Number sort desc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByAmmountAsc), " Amount sort asc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.orderByAmmountDesc), " Amount sort desc should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.refreshButton), " Refresh button should be visible");
            Assert.IsTrue(dcPage.isElementPresent(dcPage.selectShowEntries), " Show Entries select should be visible");

            Thread.Sleep(2000);
        }
    }
}
