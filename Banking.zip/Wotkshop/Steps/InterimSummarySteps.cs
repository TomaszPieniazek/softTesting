﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PageObjects.HomePage.Notices.PrintOptions;
using PageObjects.HomePage;
using TechTalk.SpecFlow;
using PageObjects.HomePage.Notices.InterimSummary;
using OpenQA.Selenium.Support.PageObjects;
using System.Threading;
using NUnit.Framework;

namespace Wotkshop.Steps
{
    [Binding]
    class InterimSummarySteps
    {
        private IWebDriver driver = HomePage.sendDriver();
        private InterimSummary isPage;

        [When(@"init InterimSummary")]
        public void WhenInitInterimSummary()
        {
            isPage = new InterimSummary(driver);
            PageFactory.InitElements(driver, isPage);
        }

        [Then(@"user checks if all elements on interim summary view exists")]
        public void ThenUserChecksIfAllElementsOnInterimSummaryViewExists()
        {
            Thread.Sleep(2000);

            Assert.IsTrue(isPage.isElementPresent(isPage.AccountNumberInput), " Account Number input should be visible");
            Assert.IsTrue(isPage.isElementPresent(isPage.StartDate), " Start Date  should be visible");
            Assert.IsTrue(isPage.isElementPresent(isPage.EndDate), " End Date should be visible");
            Assert.IsTrue(isPage.isElementPresent(isPage.GenerateSummaryButton), " Generate Summary button should be visible");

        }


    }
}
