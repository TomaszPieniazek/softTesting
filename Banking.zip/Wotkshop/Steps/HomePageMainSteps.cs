﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.PageObjects;
using PageObjects.HomePage;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System.Threading;
using PageObjects.HomePage.Support.CaseMaintenance;

namespace Wotkshop
{
    [Binding]
    public class HomePageMainSteps
    {
        private static IWebDriver driver;
        private HomePage homePage;
        private CaseMaintenance casePage;



        [Given(@"user goes to bankWatcher")]
        public void GivenUserGoesToBankWatcher()
        {
            homePage = new HomePage(driver);
            PageFactory.InitElements(driver, homePage);
            homePage.OpenBankWatcher();

        }



        [When(@"user expands menu(.*)")]
        public void WhenUserTypesSeleniunIntoSearchInput(String menuOption)
        {
            homePage.ExpandMenuOption(menuOption);

        }

        [When(@"user clicks on menu option(.*)")]
        public void WhenUserClicksSearch(String option)
        {
            homePage.ClickOnDetailedMenuOption(option);
            
           
        }



        [Then(@"user should be on result page")]
        public void ThenUserShouldBeOnResultPage()
        {
        }
        [AfterFeature]
        public static void AfterScenario()
        {
            driver.Close();
        }

        [BeforeFeature]
        public static void beforeEachStory()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            
        }
    }
}
