﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;

namespace PageObjects.HomePage.Notices.PrintOptions
{
     class PrintOptions : HomePage
    {

        public PrintOptions(IWebDriver driverInit) : base(driverInit)
        {

        }

        [FindsBy(How = How.XPath, Using = "//input[@id='formSubmit']")]
        public IWebElement SaveChangesButton { get; set; }

        //siteID
        [FindsBy(How = How.XPath, Using = "//span[@class='select2-selection__arrow']")] //siteID arrow
        public IWebElement SiteIDArrow { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='select2-selection select2-selection--single']")] //siteID 
        public IWebElement SiteID { get; set; }

        //Address elements
        [FindsBy(How = How.XPath, Using = "//input[@id='attentionInput']")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='address1Input']")]
        public IWebElement FirstAddress { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='address2Input']")]
        public IWebElement SecondAddress { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='cityInput']")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='stateInput']")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='zipCodeInput']")]
        public IWebElement ZipCode { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='removeAddressCheckbox']")]
        public IWebElement RemoveAddressCheckbox { get; set; }

        [FindsBy(How = How.XPath, Using = "//select[@id='caseSortDropDown']")]
        public IWebElement CaseSort { get; set; }

        [FindsBy(How = How.XPath, Using = "//select[@id='printModeDropDown']")]
        public IWebElement PrintMode { get; set; }

        //elements available after selecting some Site ID
        [FindsBy(How = How.XPath, Using = "//div[@class='table-responsive']//input[@type='checkbox']")]
        public IWebElement TrusteeSelectedCheckbox { get; set; } //all of them (one or more) 

    }
}