﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;

namespace PageObjects.HomePage.Notices.DepositConfirmations
{
     class DepositConfirmationsPage : HomePage
    {
        private String URL = "https://slatbwtst01/#/Notices/DepositConfirmations";
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;

        public DepositConfirmationsPage(IWebDriver driverInit) : base(driverInit)
        {

        }



        //Xpath sections, describe here all of the xpath related to page
        // check deocumentation for "How", there are multiple variations of how find elements.
        //expand filter options
        [FindsBy(How = How.XPath, Using = "//span[contains(@class,'fa fa-plus')]/..")]
        public IWebElement expandFilterButtonPlus { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(@class,'fa fa-minus')]/..")]
        public IWebElement expandFilterButtonMinus { get; set; }

        //Filter inputs + filter button
        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'accountNumberInput')]")]
        public IWebElement accountNumberInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//select[contains(@id,'bankCodeInput')]")]
        public IWebElement selectBankCodeDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'startDateInput')]")]
        public IWebElement startDateInputDatePicker { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'endDateInput')]")]
        public IWebElement endDateInputDatePicker { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'formSubmit')]")]
        public IWebElement filterButtonSubmit { get; set; }

        //sort buttons in table
        [FindsBy(How = How.XPath, Using = "//span[.='Bank Code']/..//span[contains(@ng-click,'Ascending')]")]
        public IWebElement orderByBankCodeAsc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Bank Code']/..//span[contains(@ng-click,'Descending')]")]
        public IWebElement orderByBankCodeDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Account']/..//span[contains(@ng-click,'Ascending')]")]
        public IWebElement orderByAccountAsc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Account']/..//span[contains(@ng-click,'Descending')]")]
        public IWebElement orderByAccountDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Deposit Type']/..//span[contains(@ng-click,'Ascending')]")]
        public IWebElement orderByDepositTypeAsc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Deposit Type']/..//span[contains(@ng-click,'Descending')]")]
        public IWebElement orderByDepositTypeDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Trans. Date']/..//span[contains(@ng-click,'Ascending')]")]
        public IWebElement orderByTransDateAsc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Trans. Date']/..//span[contains(@ng-click,'Descending')]")]
        public IWebElement orderByTransDateDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Ref. No']/..//span[contains(@ng-click,'Ascending')]")]
        public IWebElement orderByRefNoAsc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Ref. No']/..//span[contains(@ng-click,'Descending')]")]
        public IWebElement orderByRefNoDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Amount']/..//span[contains(@ng-click,'Ascending')]")]
        public IWebElement orderByAmmountAsc { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Amount']/..//span[contains(@ng-click,'Descending')]")]
        public IWebElement orderByAmmountDesc { get; set; }

        //others page elements and pagination
        [FindsBy(How = How.XPath, Using = "//a[contains(@ng-click,'refresh()')]")]
        public IWebElement refreshButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//select[contains(@id,'pagination')]")]
        public IWebElement selectShowEntries { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[contains(@ng-show,'GoToFirstPage')]")]
        public IWebElement goToFirstPageButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[contains(@ng-show,'GoToLastPage')]")]
        public IWebElement goToLastPageButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[contains(@ng-show,'GoToNextPage')]")]
        public IWebElement goToNextPageButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[contains(@ng-show,'GoToPreviousPage')]")]
        public IWebElement goToPreviousPageButton { get; set; }
    }
}
