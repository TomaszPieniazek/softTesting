﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.Notices.InterimSummary
{


    //className
    class InterimSummary : HomePage
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;

        public InterimSummary(IWebDriver driverInit) : base(driverInit)
        {

        }



        //Xpath sections, describe here all of the xpath related to page
        // check deocumentation for "How", there are multiple variations of how find elements.

        //account number
        [FindsBy(How = How.XPath, Using = "//input[@id='accountNumberInput']")]
        public IWebElement AccountNumberInput { get; set; }

        //fields for date
        [FindsBy(How = How.XPath, Using = "//input[@id='startDate']")]
        public IWebElement StartDate { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='endDate']")]
        public IWebElement EndDate { get; set; }

        //others
        [FindsBy(How = How.XPath, Using = "//input[@id='formSubmit']")]
        public IWebElement GenerateSummaryButton { get; set; }                           
    }
       
}