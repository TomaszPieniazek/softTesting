﻿
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Windows.Input;
using System.Threading;
using System.Windows;
using Simplify.Windows.Forms;
using WindowsInput.Native;
using WindowsInput;
using PageObjects.HomePage.Support.CaseMaintenance;




namespace PageObjects.HomePage
{
    class HomePage

    {
        private static IWebDriver driver;

        private string naviMenuXpathBuilder = "//ul[@class='sidebar-menu']//span";

        public void WaitForElementIsVisible(IWebElement elem)
        {
            DefaultWait<IWebDriver> fluentWait = new DefaultWait<IWebDriver>(driver);
            fluentWait.Timeout = TimeSpan.FromSeconds(5);
            fluentWait.PollingInterval = TimeSpan.FromMilliseconds(250);
            fluentWait.IgnoreExceptionTypes(typeof(NoSuchElementException));
            fluentWait.Until(ExpectedConditions.ElementToBeClickable(elem));
            Thread.Sleep(1500);

        }

        public void WaitForElementIsVisible(String xpath)
        {
            DefaultWait<IWebDriver> fluentWait = new DefaultWait<IWebDriver>(driver);
            fluentWait.Timeout = TimeSpan.FromSeconds(5);
            fluentWait.PollingInterval = TimeSpan.FromMilliseconds(250);
            fluentWait.IgnoreExceptionTypes(typeof(NoSuchElementException));
            fluentWait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(xpath)));
        }

        public void ExpandMenuOption(string menuOption)
        {
            try
            {
                Thread.Sleep(1500);
                IWebElement menuOptionObject = driver.FindElement(By.XPath(naviMenuXpathBuilder + "[.=normalize-space('"+menuOption+"')]"));
                WaitForElementIsVisible(menuOptionObject);
                menuOptionObject.Click();
            }
            catch (Exception)
            {
                Thread.Sleep(3500);
                IWebElement menuOptionObject = driver.FindElement(By.XPath(naviMenuXpathBuilder + "[.=normalize-space('" + menuOption + "')]"));
                WaitForElementIsVisible(menuOptionObject);
                menuOptionObject.Click();
                

            }
          

        }


        public void ClickOnMenuOption(string menuOption)
        {
            IWebElement menuOptionObject = driver.FindElement(By.XPath(naviMenuXpathBuilder + "[.='" + menuOption + "']"));
            WaitForElementIsVisible(menuOptionObject);
            menuOptionObject.Click();

        }

       

        public void ClickOnDetailedMenuOption(string detailedOption)
        {
            try
            {
                IWebElement detailedMenu = driver.FindElement(By.XPath("//a[.=normalize-space('" + detailedOption + "')]"));
                WaitForElementIsVisible(detailedMenu);
                detailedMenu.Click();
                
            }
            catch (Exception)
            {
                Thread.Sleep(2500);
                IWebElement detailedMenu = driver.FindElement(By.XPath("//a[.=normalize-space('" + detailedOption + "')]"));
                WaitForElementIsVisible(detailedMenu);
                detailedMenu.Click();
            }
        }

      
        public CaseMaintenance gotoMaint()
        {
            CaseMaintenance page = new CaseMaintenance(driver);
            PageFactory.InitElements(driver, page);
            return page;

        }


        public HomePage(IWebDriver driverInit)
        {
            driver = driverInit;
            PageFactory.InitElements(driver, this);
        }

        public void SetUp()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
        }

        public void OpenBankWatcher()
        {

            // InputSimulator 
            // This is used to simulate keyboard buttons (press buton, release button etc)
            //It is workaround to handle auth. popup
            //note: It may be not working when tests are running from bamboo
            driver.Navigate().GoToUrl("https://slatbwtst01/");
            Thread.Sleep(5000);
            InputSimulator s = new InputSimulator();
            
            s.Keyboard.TextEntry("QAadmin");
            Thread.Sleep(1000);
            s.Keyboard.KeyPress(WindowsInput.Native.VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            s.Keyboard.TextEntry("Testmeout!");
            Thread.Sleep(1000);
            s.Keyboard.KeyPress(WindowsInput.Native.VirtualKeyCode.RETURN);

        }

        // Method to send current driver (it has to be accessible for all step classes)
        public static IWebDriver sendDriver()
        {
            return driver;
        }

       public bool isElementPresent(IWebElement elem)
        {
            bool result = false;
        try {
                result = elem.Displayed;
            } catch (NoSuchElementException e) {
        }

        return result;
    }
    }
}
