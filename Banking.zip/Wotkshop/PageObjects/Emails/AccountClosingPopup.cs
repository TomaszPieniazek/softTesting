﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.Emails.Emails
{
    class AcountClosingPopup
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections

        //fields from popup
        [FindsBy(How = How.XPath, Using = "//input[@id='fromInput']")]
        public IWebElement FromInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='toInput']")]
        public IWebElement ToInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='ccInput']")]
        public IWebElement CCInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='subjectInput']")]
        public IWebElement SubjectInput { get; set; }

        //content text area
        [FindsBy(How = How.XPath, Using = "//div[@id='cke_947_contents']")]
        public IWebElement ContentTextArea { get; set; }

        //buttons
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default pull-left']")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary ng-scope']")]
        public IWebElement SendButton { get; set; }
             
     }
}

