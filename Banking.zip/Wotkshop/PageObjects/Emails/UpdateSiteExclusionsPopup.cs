﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.Emails.Emails
{
    class UpdateSiteExclusionsPopup
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections

        //siteid input
        [FindsBy(How = How.XPath, Using = "//input[@name='siteid']")]
        public IWebElement SiteIdInput { get; set; }

        // Add siteId button
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-success']")]
        public IWebElement AddSiteIdButton { get; set; }

        //siteid Icon
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-danger btn-emails ng-binding']")]
        public IWebElement SiteIdIcon { get; set; }

        public UpdateSiteExclusionsPopup DeleteIconWithSiteID(string siteid)
        {
           IWebElement elem;
           elem = driver.FindElement(By.XPath("//a[@class='btn btn-danger btn-emails ng-binding']//..//a[contains(.,'" + siteid +"')]"));
           elem.Click();
           return this;
        }
     }
}

