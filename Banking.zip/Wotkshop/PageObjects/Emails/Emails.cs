﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.Emails.Emails
{


    //className
    class Emails
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections, describe here all of the xpath related to page


        //sorting on table
        //sort on Trustee No       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Trustee No')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement TrusteeNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Trustee No')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement TrusteeNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Trustee No')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement TrusteeNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Trustee No')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement TrusteeNoDownActiv { get; set; }

        //sort on Last Name       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Last Name')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement LastNameUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Last Name')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement LastNameUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Last Name')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement LastNameDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Last Name')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement LastNameDownActiv { get; set; }

        //sort on Main Email       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Main Email')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement MainEmailUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Main Email')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement MainEmailUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Main Email')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement MainEmailDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Main Email')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement MainEmailDownActiv { get; set; }

        //sort on Additional Email       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Additional Email')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement AdditionalEmailUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Additional Email')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement AdditionalEmailUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Additional Email')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement AdditionalEmailDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Additional Email')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement AdditionalEmailDownActiv { get; set; }

        //buttons
        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-download']")]
        public IWebElement DownloadButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-refresh']")]
        public IWebElement RefreshButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-success']")]
        public IWebElement UpdateSiteExclusionsButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']//..//a[contains(.,'Custom Email')]")]
        public IWebElement CustomEmailsButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']//..//a[contains(.,'Account Closing')]")]
        public IWebElement AccountClosingButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']//..//a[contains(.,'TFR Refund')]")]
        public IWebElement TFRRefundButton { get; set; }
    }
       
}

