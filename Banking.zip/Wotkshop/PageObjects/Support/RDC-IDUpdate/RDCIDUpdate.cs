﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.Support.RDCIDUpdate
{


    //className
    class RDCIDUpdate : HomePage
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;

        public RDCIDUpdate(IWebDriver driver) : base(driver)
        {

        }



        //Xpath sections, describe here all of the xpath related to page
        // check deocumentation for "How", there are multiple variations of how find elements.

        //Filters
        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-plus']")]
        public IWebElement FiltersPlus { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-minus']")]
        public IWebElement FiltersMinus { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='trusteeName']")]
        public IWebElement FiduciaryName { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='trusteeSurname']")]
        public IWebElement FiduciarySurname { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='siteId']")]
        public IWebElement SiteID { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='formSubmit']")]
        public IWebElement FilterButton { get; set; }

        //Table

        //Fiduciary Name Sort       
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Name')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement FiduciaryNameSortUpActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Name')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement FiduciaryNameSortUpInactive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Name')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement FiduciaryNameSortDownActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Name')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement FiduciaryNameSortDownInactive { get; set; }

        //Fiduciary Surname Sort
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Surname')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement FiduciarySurnameSortUpActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Surname')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement FiduciarySurnameSortUpInactive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Surname')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement FiduciarySurnameSortDownActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Fiduciary Surname')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement FiduciarySurnameSortDownInactive { get; set; }

        //Siteid Sort
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement SiteIdSortUpActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement SiteIdSortUpInactive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement SiteIdSortDownActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement SiteIdSortDownInactive { get; set; }


        //RDC-ID dropdown
        // [FindsBy(How = How.XPath, Using = "//select[contains(@ng-model,'isRdc')]")]
        //  public IWebElement SiteIdSortDownInactive { get; set; } //all visible on page rdc-id dropdowns

        //others
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }

        //Methods section
        //Methods for smoke tests

        public RDCIDUpdate expandFilterSectionIfNeeded()
        {
            if (isElementPresent(FiltersPlus))
            {
                FiltersPlus.Click();
            }
            return this;
        }

        public bool checkFilterArrowsInRdcidUpdate()
        {
            bool result = false;
            int inActiveArrowsCount = 0;
            if (isElementPresent(FiduciaryNameSortDownInactive))
            {
                inActiveArrowsCount++;
            }
            if (isElementPresent(FiduciaryNameSortUpInactive))
            {
                inActiveArrowsCount++;
            }
            if (isElementPresent(FiduciarySurnameSortDownInactive))
            {
                inActiveArrowsCount++;
            }
            if (isElementPresent(FiduciarySurnameSortUpInactive))
            {
                inActiveArrowsCount++;
            }
            if (isElementPresent(SiteIdSortDownInactive))
            {
                inActiveArrowsCount++;
            }
            if (isElementPresent(SiteIdSortUpInactive))
            {
                inActiveArrowsCount++;
            }
            if (inActiveArrowsCount == 5)
            {
                result = true;
            }
            return result;
        }
    }
       
}