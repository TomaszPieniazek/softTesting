﻿// IMPORT PACKAGES//

using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Windows.Input;
using System.Threading;
using System.Windows;
using Simplify.Windows.Forms;
using WindowsInput.Native;
using WindowsInput;



//namespace
namespace PageObjects.HomePage.Support.CaseMaintenance
{

    //className

    //Inherit by or basePage (HomePage)
    class CaseMaintenance : HomePage
    {

        public CaseMaintenance(IWebDriver driver) : base(driver)
        {
   
        }



        //Xpath sections, describe here all of the xpath related to page
        // check deocumentation for "How", there are multiple variations of how find elements.

        //table
        [FindsBy(How = How.XPath, Using = "//table[@class='table table-bordered table-hover dataTable']")]
        public IWebElement MainTable { get; set; }

        //1stEntryBy sort
        [FindsBy(How = How.XPath, Using = "//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement stEntryByUpActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement stEntryByUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement stEntryByDownActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement stEntryByDownInactiv { get; set; }

        //1stEntryAt sort
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'1st Entry At')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement stEntryAtUpActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'1st Entry At')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement stEntryAtUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'1st Entry At')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement stEntryAtDownActive { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'1st Entry At')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement stEntryAtDownInactiv { get; set; }

        //rows from table

        //Commands
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-success btn-responsive']")]
        public IWebElement DownloadButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary btn-responsive ng-scope']")]
        public IWebElement EditButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-danger btn-responsive']")]
        public IWebElement DeleteButton { get; set; }


        //other from Case Maintance
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary btn-responsive pull-right']")]
        public IWebElement AddEntryButton { get; set; }
            
    }

    //className
    class CaseMaintenanceAddEntry
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections

        //dropdowns from popup Add first entry
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-siteId-container']")]
        public IWebElement SiteIdDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-siteId-results']")]
        public IWebElement SiteIdDropDownList { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-caseNumber-container']")]
        public IWebElement CaseNoDropDownField { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-caseNumber-results']")]
        public IWebElement CaseNoDropDownList { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-operationType-container']")]
        public IWebElement OperationTypeDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-operationType-results']")]
        public IWebElement OperationTypeDropDownList { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-toTrusteeNumber-container']")]
        public IWebElement ToTrusteeNumberDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-toTrusteeNumber-results']")]
        public IWebElement ToTrusteeNumberDropDownList { get; set; }

        //inputs from popup Add first entry
        [FindsBy(How = How.XPath, Using = "//input[@id='caseName1']")]
        public IWebElement CaseName1Input { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='caseName2']")]
        public IWebElement CaseName2Input { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='tin']")]
        public IWebElement TinInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='tin2']")]
        public IWebElement Tin2Input { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='newCaseNumber']")]
        public IWebElement NewCaseNumberInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//textarea[@id='firstEntryComment']")]
        public IWebElement FirstEntryComment { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='attachment']")]
        public IWebElement AttachmentInput { get; set; }
        
        //Others
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn - default pull - left']")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary ng-scope']")]
        public IWebElement SubmitButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='close']")]
        public IWebElement CloseButton { get; set; }


    }
}