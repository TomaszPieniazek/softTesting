﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.Support.CaseMaintenance.AddEntryPopup
{
    class CaseMaintenanceAddEntryPopup
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections

        //dropdowns from popup Add first entry
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-siteId-container']")]
        public IWebElement SiteIdDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-siteId-results']")]
        public IWebElement SiteIdDropDownList { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-caseNumber-container']")]
        public IWebElement CaseNoDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-caseNumber-results']")]
        public IWebElement CaseNoDropDownList { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-operationType-container']")]
        public IWebElement OperationTypeDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-operationType-results']")]
        public IWebElement OperationTypeDropDownList { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-toTrusteeNumber-container']")]
        public IWebElement ToTrusteeNumberDropDownField { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-toTrusteeNumber-results']")]
        public IWebElement ToTrusteeNumberDropDownList { get; set; }

        //inputs from popup Add first entry
        [FindsBy(How = How.XPath, Using = "//input[@id='caseName1']")]
        public IWebElement CaseName1Input { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='caseName2']")]
        public IWebElement CaseName2Input { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='tin']")]
        public IWebElement TinInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='tin2']")]
        public IWebElement Tin2Input { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='newCaseNumber']")]
        public IWebElement NewCaseNumberInput { get; set; }

        [FindsBy(How = How.XPath, Using = "//textarea[@id='firstEntryComment']")]
        public IWebElement FirstEntryComment { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='attachment']")]
        public IWebElement AttachmentInput { get; set; }

        //Others
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn - default pull - left']")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary ng-scope']")]
        public IWebElement SubmitButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='close']")]
        public IWebElement CloseButton { get; set; }


    }
}