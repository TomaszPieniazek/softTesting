﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;

namespace Wotkshop.PageObjects.Support.AccountMaintenance
{
    class UploadCloseList
    {
        private IWebDriver driver;

        //cancel
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default']")]
        public IWebElement Cancel { get; set; }

        //validate&continue
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary']")]
        public IWebElement Validate { get; set; }

        //1stComment
        [FindsBy(How = How.XPath, Using = "//textarea[@ng-model='accountNumbers']")]
        public IWebElement AccountName { get; set; }

        //show/hide details
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-sm btn-primary']")]
        public IWebElement ContinueBtn { get; set; }

        //close
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default pull-left ng-binding']")]
        public IWebElement Close { get; set; }

    }
}
