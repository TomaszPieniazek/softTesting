﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.Support.AccountMaintenance
{
    class AccountMaintenance
    {
        private IWebDriver driver;

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary pull-right margin-r-5']")]
        public IWebElement UploadCloseList { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary btn-responsive pull-right margin-r-5']")]
        public IWebElement AddSweepAccount { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary btn-responsive pull-right']")]
        public IWebElement AddEntry { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement Refresh { get; set; }

        //Sort table
        [FindsBy(How = How.XPath, Using = "//span[.='1st Entry By']//..//span[@ng-click='sortAscending(orderBy)']")]
        public IWebElement SortUpEntryBy { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='1st Entry By']//..//span[@ng-click='sortDescending(orderBy)']")]
        public IWebElement SortDownEntryBy { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='1st Entry At']//..//span[@ng-click='sortAscending(orderBy)']")]
        public IWebElement SortUpEntryAt { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='1st Entry At']//..//span[@ng-click='sortDescending(orderBy)']")]
        public IWebElement SortDownEntryAt { get; set; }

        //Commands from table
        [FindsBy(How=How.XPath, Using = "//a[@class='btn btn-success btn-responsive']")]
        public IWebElement DownloadButton { get; set; }

        [FindsBy(How=How.XPath,Using = "//a[@class='btn btn-primary btn-responsive ng-scope']")]
        public IWebElement EditButton { get; set; }

        [FindsBy(How=How.XPath,Using = "//a[@class='btn btn-danger btn-responsive']")]
        public IWebElement DeleteButton { get; set; }

    }
}
