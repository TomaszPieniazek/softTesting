﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;

namespace Wotkshop.PageObjects.Support.AccountMaintenance
{
    class AddSweepAccount
    {
        private IWebDriver driver;

        //cancel
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default pull-left']")]
        public IWebElement Cancel { get; set; }

        //siteid
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-siteId-container']")]
        public IWebElement SiteIdDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-siteId-results']")]
        public IWebElement SiteIdDropDownList { get; set; }

        //trustee
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-trusteeNumber-container']")]
        public IWebElement TrusteeDropDown{ get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-trusteeNumber-results']")]
        public IWebElement TrusteeDropDownList { get; set; }

        //bank
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-bankCode-container']")]
        public IWebElement BankDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-bankCode-results']")]
        public IWebElement BankDropDownList { get; set; }

        //1stComment
        [FindsBy(How = How.XPath, Using = "//textarea[@id='firstEntryComment']")]
        public IWebElement AccountName { get; set; }

        //attachment
        [FindsBy(How = How.XPath, Using = "//input[@id='attachment']")]
        public IWebElement Attachment { get; set; }

        //submit
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary ng-scope']")]
        public IWebElement Submit { get; set; }
    }
}
