﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;

namespace Wotkshop.PageObjects.Support.AccountMaintenance
{
    class AddEntry
    {
        private IWebDriver driver;

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default pull-left']")]
        public IWebElement Cancel { get; set; }

        //siteId
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-siteId-container']")]
        public IWebElement SiteIdDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-siteId-results']")]
        public IWebElement SiteIdDropDownList { get; set; }

        //trustee
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-trusteeNumber-container']")]
        public IWebElement TrusteeDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-trusteeNumber-results']")]
        public IWebElement TrusteeDropDownList { get; set; }

        //caseNo
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-caseNumber-container']")]
        public IWebElement CaseNoDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-caseNumber-results']")]
        public IWebElement CaseNoDropDownList { get; set; }

        //accountNo
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-accountNumber-container']")]
        public IWebElement AccountNoDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-accountNumber-results']")]
        public IWebElement AccountNoDropDownList { get; set; }

        //accountType
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-accountType-container']")]
        public IWebElement AccountTypeDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@ul='select2-accountType-results']")]
        public IWebElement AccountTypeDropDownList { get; set; }

        //operation
        [FindsBy(How = How.XPath, Using = "//span[@aria-labelledby='select2-operationType-container']")]
        public IWebElement OperationDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='select2-operationType-results']")]
        public IWebElement OperationDropDownList { get; set; }

        //accountName
        [FindsBy(How = How.XPath, Using = "//input[@id='accountName']")]
        public IWebElement AccountName { get; set; }

        //Date
        [FindsBy(How = How.XPath, Using = "//input[@id='maturityDate']")]
        public IWebElement MaturityDate { get; set; }

        //1stComment
        [FindsBy(How = How.XPath, Using = "//textarea[@id='firstEntryComment']")]
        public IWebElement CommentArea { get; set; }

        //submit
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary ng-scope']")]
        public IWebElement Submit { get; set; }

        //close
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default pull-left ng-binding']")]
        public IWebElement Close { get; set; }


    }
}
