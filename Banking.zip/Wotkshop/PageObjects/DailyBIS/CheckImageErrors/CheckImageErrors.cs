﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.DailyBIS.CheckImageErrors
{


    //className
    class CheckImageErrors : HomePage
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;

        public CheckImageErrors(IWebDriver driver) : base(driver)
        {

        }



        //Xpath sections, describe here all of the xpath related to page

        //Filters
        //fields from filter
        [FindsBy(How = How.XPath, Using = "//select[contains(@id,'bankCode')]")]
        private IWebElement BankCodeDropdown { get; set; }
              
                
        
        //sorting on table
        //sort on File Name       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement FileNameUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement FileNameUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement FileNameDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement FileNameDownActiv { get; set; }

        //sort on Modified On       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Modified On')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement ModifiedOnUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Modified On')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement ModifiedOnUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Modified On')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement ModifiedOnDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Modified On')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement ModifiedOnDownActiv { get; set; }
        
        //sort on Created On       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CreatedOnUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CreatedOnUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CreatedOnDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CreatedOnDownActiv { get; set; }

        //sort on Size       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement SizeUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement SizeUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement SizeDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement SizeDownActiv { get; set; }



        //rename buttons       
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-responsive']")]
        public IWebElement RenameButton { get; set; } //all buttons from column


        //download from hyperlink        
        public CheckAccountNumberCorrectionPopup OpenPopupFromLink(string link)
        {
            IWebElement elem = driver.FindElement(By.XPath("//td[contains(.,'" + link + "')]"));


  

            elem.Click();
            CheckAccountNumberCorrectionPopup popup = new CheckAccountNumberCorrectionPopup(driver);
            PageFactory.InitElements(driver, popup);
           
            return popup;
        }

        //refresh button
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }

        //purge button
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app ng-binding']")]
        public IWebElement PurgeButton { get; set; }

    }

}


