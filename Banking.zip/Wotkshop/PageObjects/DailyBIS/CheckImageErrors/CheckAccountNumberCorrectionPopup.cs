﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.DailyBIS.CheckImageErrors
{


    //className
    class CheckAccountNumberCorrectionPopup : HomePage
    {
        private IWebDriver driver;

        public CheckAccountNumberCorrectionPopup(IWebDriver driver) : base(driver)
        {
            
        }

        
        //new account number input
        [FindsBy(How = How.XPath, Using = "//input[@id='newAccountNumber']")]
        private IWebElement NewAccountNumberInput { get; set; }
              
        
        //buttons       
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-default pull-left']")]
        public IWebElement CancelButton { get; set; } //all buttons from column

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary ng-scope']")]
        public IWebElement UpdateButton { get; set; } //all buttons from column



    }

}


