﻿// IMPORT PACKAGES//
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;




//namespace
namespace PageObjects.HomePage.DailyBIS.NonPostReport
{


    //className
    class NonPostReport
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections, describe here all of the xpath related to page

        //Filters
        //plus/minus
        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-plus']")]
        public IWebElement FiltersPlus { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-minus']")]
        public IWebElement FiltersMinus { get; set; }

        //fields from filter
        [FindsBy(How = How.XPath, Using = "//select[contains(@id,'bankCode')]")]
        private IWebElement BankCodeDropdown { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='fromDate']")]
        public IWebElement DateFromInput { get; set; }

 //       [FindsBy(How = How.XPath, Using = "//input[@id='toDate']")]
 //       public IWebElement DateToInput { get; set; }

 //       //buttons from filter
        [FindsBy(How = How.XPath, Using = "//input[@type='submit']")]
 //       public IWebElement DateToInput { get; set; }

 //       [FindsBy(How = How.XPath, Using = "//input[@type='reset']")]
 //       public IWebElement DateToInput { get; set; }


        


        //sorting on table
        //sort on File Name       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement FileNameUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement FileNameUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement FileNameDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'File Name')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement FileNameDownActiv { get; set; }

        //sort on Size       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement SizeUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement SizeUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement SizeDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Size')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement SizeDownActiv { get; set; }

        //sort on Created On       
        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CreatedOnUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CreatedOnUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CreatedOnDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[contains(.,'Created On')]//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CreatedOnDownActiv { get; set; }

        //rename buttons       
        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-responsive']")]
        public IWebElement AdditionalEmailUpInactiv { get; set; } //all buttons from column


        //download from hyperlink        
        public NonPostReport DownloadFile(string link)
        {
       //     WebElement elem;
         //   elem = driver.findElement(By.xpath("//a[contains(.,'" + link + "')]"));
          //  elem.click();
            return this;
        }

        //refresh button
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }

    }

}



