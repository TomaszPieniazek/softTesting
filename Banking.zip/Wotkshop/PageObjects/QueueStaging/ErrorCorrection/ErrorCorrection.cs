﻿/*
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Chrome;



//namespace
namespace PageObjects.HomePage.QueueStaging.ErrorCorrection
{
    //

    //className
    class ErrorCorrections
    {
        // Declare IwebDriver object, to be able to use webDriver
        private IWebDriver driver;



        //Xpath sections, describe here all of the xpath related to page
        // check deocumentation for "How", there are multiple variations of how find elements.

        //Account Processing Errors Tab
        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Account Processing Errors')]")]
        public IWebElement AccountProcessingErrorsTab { get; set; }

        //Filters
        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-plus']")]
        public IWebElement FiltersPlus { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-minus']")]
        public IWebElement FiltersMinus { get; set; }
            
        //buttons from filter
        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Hide Selected Filters')]")]
        public IWebElement HideSelectedFiltersButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Purge Selected Filters')]")]
        public IWebElement PurgeSelectedFiltersButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Reset Selected Filters')]")]
        public IWebElement ResetSelectedFiltersButton { get; set; }

        //checkbox from filter
        [FindsBy(How = How.XPath, Using = "//input[@id='closedAccounts']")]
        public IWebElement ResetSelectedFiltersButton { get; set; }



        //table
        //sort on id
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Id') and not(contains(.,'Site Id'))and not(contains(.,'CQ Id'))and not(contains(.,'Batch Id'))]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement IdUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Id') and not(contains(.,'Site Id'))and not(contains(.,'CQ Id'))and not(contains(.,'Batch Id'))]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement IdUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Id') and not(contains(.,'Site Id'))and not(contains(.,'CQ Id'))and not(contains(.,'Batch Id'))]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement IdDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Id') and not(contains(.,'Site Id'))and not(contains(.,'CQ Id'))and not(contains(.,'Batch Id'))]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement IdDownInactiv { get; set; }

        //sort on CQ id
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'CQ Id')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CQIdUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'CQ Id')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CQIdUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'CQ Id')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CQIdDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'CQ Id')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CQIdDownActiv { get; set; }

        //sort on Error
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Error')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement ErrorUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Error')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement ErrorUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Error')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement ErrorDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Error')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement ErrorDownActiv { get; set; }

        //sort on Site id
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement SiteIdUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement SiteIdUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement SiteIdDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Site Id')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement SiteIdDownActiv { get; set; }

        //sort on Bank Code
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Bank Code')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement BankCodeUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Bank Code')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement BankCodeUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Bank Code')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement BankCodeDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Bank Code')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement BankCodeDownActiv { get; set; }

        //sort on Trustee No.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Trustee No.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement TrusteeNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Trustee No.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement TrusteeNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Trustee No.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement TrusteeNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Trustee No.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement TrusteeNoDownActiv { get; set; }

        //sort on Case No.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case No.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CaseNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case No.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CaseNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case No.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CaseNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case No.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CaseNoDownActiv { get; set; }


        //sort on Oper.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Oper.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement OperUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Oper.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement OperUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Oper.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement OperDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Oper.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement OperDownActiv { get; set; }

        //sort on Account No
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account No')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement AccountNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account No')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement AccountNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account No')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement AccountNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account No')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement AccountNoDownActiv { get; set; }

        //sort on Type
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Type')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement TypeUpInactiv { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Type')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement TypeUpActiv { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Type')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement TypeDownInactiv { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Type')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement TypeDownActiv { get; set; }

        //sort on Account Name
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account Name')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement AccountNameUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account Name')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement AccountNameUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account Name')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement AccountNameDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Account Name')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement AccountNameDownActiv { get; set; }

        //sort on Maturity
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Maturity')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement MaturityUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Maturity')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement MaturityUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Maturity')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement MaturityDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Maturity')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement MaturityDownActiv { get; set; }

        //sort on Int. Rate
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Int. rate')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement IntRateUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Int. rate')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement IntRateUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Int. rate')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement IntRateDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Int. rate')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement IntRateDownActiv { get; set; }

        //sort on TIA Term
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIA Term')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement TIATermUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIA Term')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement TIATermUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIA Term')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement TIATermDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIA Term')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement TIATermDownActiv { get; set; }

        //sort on Created On
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Created On')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CreatedOnUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Created On')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CreatedOnUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Created On')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CreatedOnDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Created On')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CreatedOnDownActiv { get; set; }

        //sort on Batch Id
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Batch Id')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement BatchIdUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Batch Id')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement BatchIdUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Batch Id')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement BatchIdDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Batch Id')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement BatchIdDownActiv { get; set; }

        //other from Account Processin Errors Tab
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }



        //Case Processing Errors Tab
        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Case Processing Errors')]")]
        public IWebElement CaseProcessingErrorsTab { get; set; }

        
        //table
        
        //sort on Case Number
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Number')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CaseNumberUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Number')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CaseNumberUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Number')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CaseNumberDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Number')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CaseNumberDownActiv { get; set; }

        //sort on New Case No.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'New Case No.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement NewCaseNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'New Case No.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement NewCaseNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'New Case No.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement NewCaseNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'New Case No.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement NewCaseNoDownActiv { get; set; }


        //sort on Case Name
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CaseNameUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CaseNameUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CaseNameDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CaseNameDownActiv { get; set; }

        //sort on Case Name (2)
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name (2)')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement CaseName2UpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name (2)')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement CaseName2UpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name (2)')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement CaseName2DownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Case Name (2)')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement CaseName2DownActiv { get; set; }

        //sort on TIN
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement TINUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement TINUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement TINDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement TINDownActiv { get; set; }

        //sort on TIN (2)
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN (2)')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement TIN2UpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN (2)')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement TIN2UpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN (2)')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement TIN2DownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'TIN (2)')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement TIN2DownActiv { get; set; }
        
        //other from Case Processin Errors Tab
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }




        //Transaction Processing Errors Tab
        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Transaction Processing Errors')]")]
        public IWebElement AccountProcessingErrorsTab { get; set; }

        //Filters
        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-plus']")]
        public IWebElement FiltersPlus { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='fa fa-minus']")]
        public IWebElement FiltersMinus { get; set; }

        //buttons from filter
        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Hide Selected Filters')]")]
        public IWebElement HideSelectedFiltersButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Purge Selected Filters')]")]
        public IWebElement PurgeSelectedFiltersButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Reset Selected Filters')]")]
        public IWebElement ResetSelectedFiltersButton { get; set; }

        //checkbox from filter
        [FindsBy(How = How.XPath, Using = "//input[@id='tideToClosedAccounts']")]
        public IWebElement TransactionsTiedToClosedAccountsFiltersButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='duplicates']")]
        public IWebElement DuplicatedTransactionsFiltersButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='withEmptySequenceNumber']")]
        public IWebElement WithEmptySequenceNumberFiltersButton { get; set; }



        //table
        //sort on Amount
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Amount')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement AmountUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Amount')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement AmountUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Amount')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement AmountDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Amount')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement AmountDownActiv { get; set; }

        //sort on Item No.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Item No.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement ItemNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Item No.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement ItemNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Item No.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement ItemNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Item No.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement ItemNoDownActiv { get; set; }

        //sort on Payee
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Payee')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement PayeeUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Payee')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement PayeeUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Payee')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement PayeeDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Payee')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement PayeeDownActiv { get; set; }

        //sort on To Account No.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'To Account No.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement ToAccountNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'To Account No.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement ToAccountNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'To Account No.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement ToAccountNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'To Account No.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement ToAccountNoDownActiv { get; set; }

        //sort on Seq No.
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Seq No.')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement SeqNoUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Seq No.')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement SeqNoUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Seq No.')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement SeqNoDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Seq No.')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement SeqNoDownActiv { get; set; }


        //sort on Issue Date
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Issue Date')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement IssueDateUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Issue Date')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement IssueDateUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Issue Date')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement IssueDateDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Issue Date')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement IssueDateDownActiv { get; set; }

        //sort on Status Date
        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Status Date')]//..//span[@class='glyphicon glyphicon-chevron-up inactive']")]
        public IWebElement StatusDateUpInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Status Date')]//..//span[@class='glyphicon glyphicon-chevron-up active']")]
        public IWebElement StatusDateUpActiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Status Date')]//..//span[@class='glyphicon glyphicon-chevron-down inactive']")]
        public IWebElement StatusDateDownInactiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Status Date')]//..//span[@class='glyphicon glyphicon-chevron-down active']")]
        public IWebElement StatusDateDownActiv { get; set; }

      
        //other from Transaction Processin Errors Tab
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-app']")]
        public IWebElement RefreshButton { get; set; }
    }

}*/